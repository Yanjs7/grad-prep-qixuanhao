# 基于 ISIC 2017 的皮肤病灶分割与分类平台

PyTorch U-Net 分割皮肤镜病灶，ResNet18 分类黑素细胞痣、黑色素瘤和脂溢性角化病。FastAPI 提供 API 与 HTML/CSS/JavaScript 前端，支持上传、掩码和叠加图、分类概率、历史查询、ZIP 导出。

## 快速启动

推荐 Python 3.10–3.12，在解压后的项目目录执行：

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install 'torch>=2.3,<3' -r engineering/src/requirements-backend.txt
bash start_web.sh
```

访问 http://127.0.0.1:8765 ，API 文档位于 /docs 。

**源码包不包含数据集和模型权重。** 真实分析需要将 U-Net 最佳 best.pth 放为 artifacts/segmentation.pth，将 ResNet18 最佳 best.pth 放为 artifacts/classification.pth，并使用匹配配置。包内保留已训练版本配置和哈希清单；自行重训后应更新。缺少权重时页面可启动，但不能完成真实分析。

## 目录与文档

- engineering/src/models：模型定义。
- engineering/src/training：数据准备、训练、恢复与分割评估。
- engineering/src/backend、frontend：服务与页面。
- engineering/tests：已有验证脚本。
- artifacts：部署配置，权重单独提供。
- [平台使用手册](docs/平台使用手册.md)
- [详细实验报告](docs/项目实验报告.md)
- [U-Net训练说明](AUTODL_UNET训练说明.md)
- [ResNet18训练说明](RESNET训练说明.md)
- [开发指南](ISIC2017项目开发完整指南.md)：含早期设计内容，当前功能以源码和使用手册为准。
- docs/evidence：报告对应的训练指标及分类验证结果。
- third_party/unet-master：早期 Keras 参考源码，保留原 LICENSE，附带数据已移除；当前平台使用 PyTorch 实现。

## 实验结果

最佳验证结果：U-Net Dice 0.8476、IoU 0.7645；ResNet18 准确率81.33%、宏平均F1 0.7907。尚未完成全部600张测试集最终评估，以上不是测试集成绩。

## 上传 GitHub

先解压，上传目录内的源码文件，不要仅上传 ZIP。创建空仓库后可执行：

```bash
git init
git add .
git commit -m "Initial project source"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main
```

提交前使用 git status 检查。本包已补充 .gitignore。数据从 ISIC 官方获取；训练权重可通过 GitHub Releases 单独提供。运行记录、测试图像、环境、原Git历史和完整训练备份不在源码包中；文档引用这些位置时仅说明原本本地项目布局。SOURCE_MANIFEST.json 可核对包内文件哈希。

本项目用于学习研究，不能替代临床诊断。第三方源码遵循其目录的 LICENSE；未擅自为项目主体指定开源许可证。
