"""Local ResNet-18 definition compatible with official torchvision state dicts.

Architecture: He et al., Deep Residual Learning for Image Recognition.
Official ImageNet weights are downloaded only when explicitly requested.
"""
from pathlib import Path
import torch
from torch import nn

IMAGENET_URL = 'https://download.pytorch.org/models/resnet18-f37072fd.pth'
CLASS_NAMES = ('nevus', 'melanoma', 'seborrheic_keratosis')


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.downsample = None
        if stride != 1 or in_channels != out_channels:
            self.downsample = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        self.stride = stride

    def forward(self, x):
        identity = x if self.downsample is None else self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)


class ResNet18(nn.Module):
    """ResNet-18 [2, 2, 2, 2]; forward returns unnormalized class logits."""
    def __init__(self, num_classes=3):
        super().__init__()
        if num_classes < 1:
            raise ValueError('num_classes must be positive.')
        self.conv1 = nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(3, stride=2, padding=1)
        self.layer1 = self._layer(64, 64, 1)
        self.layer2 = self._layer(64, 128, 2)
        self.layer3 = self._layer(128, 256, 2)
        self.layer4 = self._layer(256, 512, 2)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    @staticmethod
    def _layer(in_channels, out_channels, stride):
        return nn.Sequential(BasicBlock(in_channels, out_channels, stride), BasicBlock(out_channels, out_channels))

    def forward(self, x):
        x = self.maxpool(self.relu(self.bn1(self.conv1(x))))
        x = self.layer4(self.layer3(self.layer2(self.layer1(x))))
        return self.fc(torch.flatten(self.avgpool(x), 1))


def resnet18(num_classes=3, *, pretrained=False, imagenet_weights_path=None):
    """Load official 1000-class ImageNet weights, then replace the head.

    imagenet_weights_path accepts an official flat state_dict, not a project
    training checkpoint. For trained project weights use model.load_state_dict.
    Default construction performs no network requests.
    """
    if not pretrained and imagenet_weights_path is None:
        return ResNet18(num_classes)
    model = ResNet18(num_classes=1000)
    if imagenet_weights_path is not None:
        state = torch.load(Path(imagenet_weights_path), map_location='cpu', weights_only=True)
    else:
        state = torch.hub.load_state_dict_from_url(
            IMAGENET_URL, map_location='cpu', check_hash=True, progress=True,
        )
    model.load_state_dict(state, strict=True)
    if num_classes != 1000:
        model.fc = nn.Linear(512, num_classes)
    return model
