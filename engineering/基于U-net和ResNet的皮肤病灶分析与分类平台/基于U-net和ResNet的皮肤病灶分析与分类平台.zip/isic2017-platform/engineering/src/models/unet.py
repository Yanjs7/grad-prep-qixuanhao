"""PyTorch U-Net for RGB lesion segmentation; returns logits, not probabilities."""
import torch
from torch import nn
from torch.nn import functional as F


class DoubleConv(nn.Sequential):
    def __init__(self, in_channels, out_channels):
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels), nn.ReLU(inplace=True),
        )


class Up(nn.Module):
    def __init__(self, in_channels, skip_channels, out_channels):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, out_channels, 2, stride=2)
        self.conv = DoubleConv(out_channels + skip_channels, out_channels)

    def forward(self, x, skip):
        x = self.up(x)
        # Odd spatial sizes can differ by one pixel after pooling.
        if x.shape[-2:] != skip.shape[-2:]:
            x = F.interpolate(x, size=skip.shape[-2:], mode='bilinear', align_corners=False)
        return self.conv(torch.cat([skip, x], dim=1))


class UNet(nn.Module):
    """Four-level U-Net with BatchNorm, RGB input and one output logit channel."""
    def __init__(self, in_channels=3, out_channels=1, base_channels=32):
        super().__init__()
        if min(in_channels, out_channels, base_channels) < 1:
            raise ValueError('Channel counts must be positive.')
        self.in_channels = in_channels
        b = base_channels
        self.inc = DoubleConv(in_channels, b)
        self.down1 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(b, b*2))
        self.down2 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(b*2, b*4))
        self.down3 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(b*4, b*8))
        self.down4 = nn.Sequential(nn.MaxPool2d(2), DoubleConv(b*8, b*16))
        self.up1 = Up(b*16, b*8, b*8)
        self.up2 = Up(b*8, b*4, b*4)
        self.up3 = Up(b*4, b*2, b*2)
        self.up4 = Up(b*2, b, b)
        self.outc = nn.Conv2d(b, out_channels, 1)

    def forward(self, x):
        if x.ndim != 4 or x.shape[1] != self.in_channels:
            raise ValueError(f'Expected NCHW tensor with {self.in_channels} channels.')
        if min(x.shape[-2:]) < 32:
            raise ValueError('Input height and width must be at least 32.')
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        return self.outc(self.up4(self.up3(self.up2(self.up1(x5, x4), x3), x2), x1))
