# PyTorch 模型源码

本项目使用以下本地模型定义，不依赖旧版 Keras 源码。

- unet.py：四级编码器/解码器 U-Net，跳跃连接、BatchNorm，默认 RGB 输入、单通道输出、基础通道 32。与原始论文的无 padding 实现不同，此实现保持输入空间尺寸，兼容奇数尺寸。
- resnet18.py：标准 BasicBlock [2,2,2,2]，提供完整本地源码；参数键与 torchvision 标准 ResNet18 对齐。默认输出三类 logits。
- __init__.py：统一导出。

## 依赖与运行

建议 Python 3.10–3.12，PyTorch >=2.2,<3。AutoDL 优先使用镜像中适配 CUDA 的 PyTorch。当前环境文件仅覆盖模型验证，不是完整平台依赖。

从项目根目录运行：

```bash
python -m engineering.src.training.check_models
```

## 使用

```python
import torch
from engineering.src.models import UNet, resnet18

seg = UNet(in_channels=3, out_channels=1, base_channels=32)
cls = resnet18(num_classes=3, pretrained=True)  # 首次需要联网下载 ImageNet 权重
seg.eval()
cls.eval()
with torch.no_grad():
    mask_prob = seg(torch.randn(1, 3, 256, 256)).sigmoid()
    class_prob = cls(torch.randn(1, 3, 224, 224)).softmax(dim=1)
```

以上随机输入仅演示接口，不是有意义的预测。U-Net 尚无训练权重；分类 ImageNet 预训练仅初始化骨干，新的三分类头必须在 ISIC 上训练。

离线加载官方 ImageNet 权重：

```python
cls = resnet18(num_classes=3, imagenet_weights_path='/path/resnet18-f37072fd.pth')
```

默认 resnet18() 不联网、随机初始化。imagenet_weights_path 只接收官方 1000 类 state_dict。项目训练好的三类权重应使用 cls.load_state_dict(torch.load(path, map_location='cpu', weights_only=True))，不要传入 ImageNet 初始化参数。

## 数据与损失约定

分类标签：0=痣（nevus），1=黑色素瘤（melanoma），2=脂溢性角化病（seborrheic_keratosis）。

分类输入 RGB，建议训练和部署统一为 224×224，先转换到 [0,1]，再用 mean=[0.485,0.456,0.406]、std=[0.229,0.224,0.225] 归一化。此统一缩放方案与官方 ImageNet 的 resize/center-crop 验证流程不同，需在 ISIC 验证集评估。

分割建议 RGB 256×256、缩放至 [0,1]；掩码使用最近邻缩放为 0/1。网络输出 logits，直接用于 BCEWithLogitsLoss；Dice 中再 sigmoid。分类 logits 直接用于 CrossEntropyLoss，展示概率时才 softmax。

模型初始化配置应随权重保存，尤其是 UNet base_channels。训练和后端共用此目录。check_models 使用小通道 U-Net 做快速梯度验证，并非正式训练配置。

## 参考

U-Net：https://arxiv.org/abs/1505.04597
ResNet：https://arxiv.org/abs/1512.03385
官方 ResNet18 文档：https://pytorch.org/vision/stable/models/generated/torchvision.models.resnet18.html
官方权重：https://download.pytorch.org/models/resnet18-f37072fd.pth

旧 Keras 示例及许可证保留在项目根目录 third_party/unet-master，仅供参考。
