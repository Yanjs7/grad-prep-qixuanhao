"""Single-user research demo. Run from project root using uvicorn."""
import io
import json
import logging
import os
import sqlite3
import threading
import time
import uuid
import warnings
import zipfile
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageOps, UnidentifiedImageError
from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from ..models import UNet, resnet18

ROOT = Path(__file__).resolve().parents[3]
FRONT = Path(__file__).resolve().parents[1] / 'frontend'
RUNTIME = Path(os.getenv('ISIC_RUNTIME', str(ROOT / 'runtime')))
ARTIFACTS = Path(os.getenv('ISIC_ARTIFACTS', str(ROOT / 'artifacts')))
LABELS = ['黑素细胞痣', '黑色素瘤', '脂溢性角化病']
LIMIT = 20 * 1024 * 1024
LOCK = threading.Lock()
models = {}
status = {}


@contextmanager
def db():
    c = sqlite3.connect(RUNTIME/'records.sqlite3', timeout=20)
    c.row_factory = sqlite3.Row
    try:
        with c:
            yield c
    finally:
        c.close()


def load_models():
    # Dedicated inference defaults to CPU so it does not contend with training.
    for name, weights, conf in [('segmentation','segmentation.pth','segmentation_config.json'),
                                ('classification','classification.pth','classification_config.json')]:
        status[name] = {'ready': False, 'message': '尚未配置模型权重', 'version': None}
        if not (ARTIFACTS/weights).exists():
            continue
        try:
            cfg = json.loads((ARTIFACTS/conf).read_text())
            size = int(cfg['image_size'])
            if not 32 <= size <= 1024: raise ValueError('image_size 应在 32–1024 之间')
            if name == 'segmentation':
                threshold = float(cfg.get('threshold', .5))
                if not 0 < threshold < 1: raise ValueError('threshold 必须在 0–1 之间')
                model = UNet(base_channels=int(cfg['base_channels']))
            else:
                if cfg.get('class_names') != ['nevus','melanoma','seborrheic_keratosis']:
                    raise ValueError('分类顺序与项目不一致')
                model = resnet18(num_classes=3)
            model.load_state_dict(torch.load(ARTIFACTS/weights,map_location='cpu',weights_only=True))
            model.eval(); models[name] = (model, cfg)
            status[name] = {'ready': True,'message':'可用','version':str(cfg.get('version','local-v1'))}
        except Exception as exc:
            status[name]['message'] = f'加载失败：{type(exc).__name__}；请检查权重与配置'
            print(f'{name}: {exc}', flush=True)


@asynccontextmanager
async def lifespan(app):
    RUNTIME.mkdir(parents=True,exist_ok=True)
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS records (id TEXT PRIMARY KEY, created_at TEXT, filename TEXT, class_id INTEGER, payload TEXT)')
    models.clear(); status.clear(); load_models()
    torch.set_num_threads(max(1,int(os.getenv('ISIC_CPU_THREADS','2'))))
    yield


app = FastAPI(title='DermaScope · 皮肤病灶分析', lifespan=lifespan)
app.mount('/static', StaticFiles(directory=FRONT), name='static')


@app.get('/')
@app.get('/history')
@app.get('/models')
@app.get('/records/{record_id}')
def page(record_id: str = ''):
    return FileResponse(FRONT/'index.html')


@app.get('/api/health')
def health():
    return {'service':'ready','device':'CPU','models':status,'labels':LABELS}


def get_record(record_id):
    with db() as c:
        row=c.execute('SELECT payload FROM records WHERE id=?',(record_id,)).fetchone()
    if row is None: raise HTTPException(404,'记录不存在')
    return json.loads(row['payload'])


@app.get('/api/records')
def records(page: int=Query(1,ge=1),page_size: int=Query(12,ge=1,le=50),q: str='',class_id: int|None=Query(None,ge=0,le=2),date: str='',tz_offset: int=Query(0,ge=-840,le=840)):
    where='WHERE filename LIKE ?'; args=['%'+q[:200]+'%']
    if class_id is not None: where+=' AND class_id=?'; args.append(class_id)
    if date:
        from datetime import timedelta
        try:
            local = datetime.strptime(date, '%Y-%m-%d').replace(tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(422, '日期格式应为 YYYY-MM-DD')
        # JS getTimezoneOffset is UTC minus local time, in minutes.
        start = local + timedelta(minutes=tz_offset)
        end = start + timedelta(days=1)
        where += ' AND created_at>=? AND created_at<?'
        args.extend([start.isoformat(), end.isoformat()])
    with db() as c:
        total=c.execute('SELECT COUNT(*) FROM records '+where,args).fetchone()[0]
        rows=c.execute('SELECT payload FROM records '+where+' ORDER BY created_at DESC LIMIT ? OFFSET ?',args+[page_size,(page-1)*page_size]).fetchall()
    return {'total':total,'page':page,'items':[json.loads(r['payload']) for r in rows]}


@app.get('/api/records/{record_id}')
def detail(record_id: str): return get_record(record_id)


@app.get('/api/records/{record_id}/files/{kind}')
def file(record_id: str,kind: str):
    get_record(record_id)
    names={'original':'original.png','mask':'mask.png','overlay':'overlay.png'}
    if kind not in names: raise HTTPException(404,'文件不存在')
    path=RUNTIME/record_id/names[kind]
    if not path.is_file(): raise HTTPException(404,'文件不存在')
    return FileResponse(path)


@app.get('/api/records/{record_id}/export')
def export(record_id: str):
    r=get_record(record_id); buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('result.json',json.dumps(r,ensure_ascii=False,indent=2))
        for name in ['original.png','mask.png','overlay.png']:
            z.write(RUNTIME/record_id/name,name)
    return Response(buf.getvalue(),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="analysis-{record_id}.zip"'})


@app.post('/api/analyze')
def analyze(file: UploadFile=File(...)):
    if 'segmentation' not in models: raise HTTPException(503,'分割模型尚未就绪，请在模型说明页查看配置状态。')
    if not LOCK.acquire(blocking=False): raise HTTPException(429,'正在处理另一个分析，请稍后重试。')
    folder=None
    request_id=uuid.uuid4().hex
    try:
        raw=file.file.read(LIMIT+1)
        if len(raw)>LIMIT: raise HTTPException(413,'图片不能超过 20MB')
        try:
            with warnings.catch_warnings():
                warnings.simplefilter('error', Image.DecompressionBombWarning)
                with Image.open(io.BytesIO(raw)) as src:
                    if src.format not in ('JPEG','PNG'): raise HTTPException(415,'仅支持 JPEG、PNG 图像')
                    if src.width*src.height>25_000_000: raise HTTPException(413,'图片不能超过 2500 万像素')
                    image=ImageOps.exif_transpose(src).convert('RGB')
        except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError,Image.DecompressionBombWarning):
            raise HTTPException(400,'图片损坏或无法解码')
        start=time.perf_counter(); model,cfg=models['segmentation']; size=int(cfg['image_size'])
        arr=np.asarray(image.resize((size,size),Image.Resampling.BILINEAR),dtype=np.float32)/255
        with torch.inference_mode():
            logits=model(torch.from_numpy(arr.transpose(2,0,1).copy())[None])
            if not torch.isfinite(logits).all(): raise RuntimeError('Non-finite model output')
            # PIL floating-point resize keeps original-size GPU/CPU tensors small.
            prob=torch.nn.functional.interpolate(logits.sigmoid(), size=(image.height,image.width), mode='bilinear', align_corners=False)[0,0].numpy()
            mask=np.asarray(prob)>=float(cfg.get('threshold',.5))
            classification=None
            if 'classification' in models:
                cm,cc=models['classification']; cs=int(cc['image_size'])
                ca=np.array(image.resize((cs,cs),Image.Resampling.BILINEAR),dtype=np.float32)/255
                ca=(ca-np.array([.485,.456,.406],dtype=np.float32))/np.array([.229,.224,.225],dtype=np.float32)
                scores=cm(torch.from_numpy(ca.transpose(2,0,1).copy())[None]).softmax(1)[0]
                if not torch.isfinite(scores).all(): raise RuntimeError('Non-finite classification output')
                ix=int(scores.argmax()); classification={'class_id':ix,'label':LABELS[ix],'probabilities':scores.tolist()}
        elapsed=(time.perf_counter()-start)*1000
        record_id=uuid.uuid4().hex; folder=RUNTIME/record_id; folder.mkdir()
        image.save(folder/'original.png'); Image.fromarray(mask.astype(np.uint8)*255).save(folder/'mask.png')
        overlay=np.array(image); overlay[mask]=(overlay[mask]*.58+np.array([20,184,166])*.42).astype(np.uint8)
        Image.fromarray(overlay).save(folder/'overlay.png')
        r={'id':record_id,'created_at':datetime.now(timezone.utc).isoformat(),'filename':Path(file.filename or 'image').name[:200],
           'image':{'width':image.width,'height':image.height},'prediction':classification,
           'segmentation':{'lesion_pixels':int(mask.sum()),'lesion_ratio':float(mask.mean())},
           'inference_ms':round(elapsed,1),'model_versions':{k:v['version'] for k,v in status.items() if v['ready']},
           'files':{k:f'/api/records/{record_id}/files/{k}' for k in ['original','mask','overlay']}}
        with db() as c:
            c.execute('INSERT INTO records VALUES (?,?,?,?,?)',(record_id,r['created_at'],r['filename'],classification['class_id'] if classification else None,json.dumps(r,ensure_ascii=False)))
        return r
    except HTTPException: raise
    except Exception:
        logging.getLogger(__name__).exception('Analysis failed request_id=%s', request_id)
        if folder:
            import shutil
            shutil.rmtree(folder,ignore_errors=True)
        raise HTTPException(500,f'分析失败，请检查服务日志和模型配置（请求编号：{request_id}）')
    finally:
        LOCK.release(); file.file.close()
