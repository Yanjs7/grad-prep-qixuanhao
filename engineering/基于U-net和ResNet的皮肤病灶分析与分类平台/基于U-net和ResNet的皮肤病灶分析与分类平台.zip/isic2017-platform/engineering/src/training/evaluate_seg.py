"""Evaluate at original image resolution and save sample overlays."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from ..models import UNet
from .seg_common import scores, config


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True); p.add_argument('--weights',required=True)
    p.add_argument('--split',choices=['val','test'],default='test')
    p.add_argument('--device',default='cpu',choices=['cpu','cuda'])
    p.add_argument('--output-dir',required=True); p.add_argument('--samples',type=int,default=12)
    a=p.parse_args(); c=config(a.config); root=Path(c['data_root'])/a.split
    rows=json.loads((root/'manifest.json').read_text())
    if not rows: raise ValueError('Empty evaluation split')
    out=Path(a.output_dir)
    if out.exists() and any(out.iterdir()): raise FileExistsError('Use an empty evaluation output directory')
    out.mkdir(parents=True,exist_ok=True)
    m=UNet(base_channels=c['base_channels']).to(a.device)
    m.load_state_dict(torch.load(a.weights,map_location='cpu',weights_only=True)); m.eval()
    results=[]
    with torch.inference_mode():
        for idx,row in enumerate(rows):
            key=row['id']
            with Image.open(root/'images'/f'{key}.jpg') as src: image=src.convert('RGB')
            with Image.open(root/'masks'/f'{key}_segmentation.png') as src: y=np.array(src.convert('L'))>0
            x=np.array(image.resize((c['image_size'],c['image_size']),Image.Resampling.BILINEAR),dtype=np.float32)/255
            prob=m(torch.from_numpy(x.transpose(2,0,1).copy())[None].to(a.device)).sigmoid()
            prob=F.interpolate(prob,size=y.shape,mode='bilinear',align_corners=False).cpu()
            d,j=scores(prob,torch.from_numpy(y.copy())[None,None],c['threshold'])
            results.append({'image_id':key,'dice':d.item(),'iou':j.item()})
            if idx<a.samples:
                mask=prob[0,0].numpy()>=c['threshold']
                Image.fromarray(mask.astype(np.uint8)*255).save(out/f'{key}_mask.png')
                overlay=np.array(image,dtype=np.float32)
                overlay[mask]=overlay[mask]*.6+np.array([255,0,0])*.4
                Image.fromarray(overlay.astype(np.uint8)).save(out/f'{key}_overlay.jpg')
    with (out/'per_image.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['image_id','dice','iou']); w.writeheader(); w.writerows(results)
    summary={'split':a.split,'count':len(results),'resolution':'original','threshold':c['threshold'],
             'dice_mean':float(np.mean([r['dice'] for r in results])),
             'iou_mean':float(np.mean([r['iou'] for r in results])),
             'dice_std':float(np.std([r['dice'] for r in results]))}
    (out/'summary.json').write_text(json.dumps(summary,indent=2)); print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
