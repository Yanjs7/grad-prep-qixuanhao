"""U-Net training. Run as a module from the project root."""
import argparse
import csv
import json
import random
import time
from pathlib import Path
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
from ..models import UNet
from .seg_data import SegDataset, fingerprint
from .seg_common import loss_fn, scores, atomic_save, config


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',default='engineering/src/configs/unet.json')
    p.add_argument('--resume'); p.add_argument('--device',choices=['cpu','cuda'])
    p.add_argument('--epochs',type=int); p.add_argument('--limit',type=int,default=0)
    p.add_argument('--output-dir'); p.add_argument('--workers',type=int)
    a=p.parse_args(); c=config(a.config)
    for key,value in [('device',a.device),('epochs',a.epochs),('output_dir',a.output_dir),('num_workers',a.workers)]:
        if value is not None: c[key]=value
    c['limit']=a.limit
    if c['epochs']<1 or a.limit<0: raise ValueError('Invalid epochs/limit')
    dev=torch.device(c['device'])
    if dev.type=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; fix the AutoDL environment or explicitly use --device cpu')
    torch.manual_seed(c['seed']); random.seed(c['seed'])
    if dev.type=='cuda': torch.cuda.manual_seed_all(c['seed'])
    data_hash=fingerprint(c['data_root'])
    train=SegDataset(c['data_root'],'train',c['image_size'],c['augment'],a.limit)
    val=SegDataset(c['data_root'],'val',c['image_size'],False,a.limit)
    gen=torch.Generator().manual_seed(c['seed'])
    loader_args={'batch_size':c['batch_size'],'num_workers':c['num_workers'],'pin_memory':dev.type=='cuda'}
    tl=DataLoader(train,shuffle=True,generator=gen,**loader_args)
    vl=DataLoader(val,shuffle=False,**loader_args)
    model=UNet(base_channels=c['base_channels']).to(dev)
    optimizer=torch.optim.Adam(model.parameters(),lr=c['learning_rate'],weight_decay=c['weight_decay'])
    amp=c['amp'] and dev.type=='cuda'
    scaler=torch.amp.GradScaler('cuda',enabled=amp)
    out=Path(c['output_dir']); start=0; best=-1.; stale=0
    if a.resume:
        ck=torch.load(a.resume,map_location='cpu',weights_only=True)
        for key in ['image_size','base_channels','batch_size','learning_rate','weight_decay','threshold','augment','seed','limit','num_workers']:
            if ck['config'][key]!=c[key]: raise ValueError(f'Resume config mismatch: {key}')
        if ck['data_hash']!=data_hash: raise ValueError('Data manifest changed since checkpoint')
        model.load_state_dict(ck['model']); optimizer.load_state_dict(ck['optimizer']); scaler.load_state_dict(ck['scaler'])
        start=ck['epoch']+1; best=ck['best']; stale=ck['stale']
        torch.set_rng_state(ck['rng']); gen.set_state(ck['loader_rng'])
        if dev.type=='cuda' and ck['cuda_rng']: torch.cuda.set_rng_state_all(ck['cuda_rng'])
        if out.resolve()!=Path(a.resume).resolve().parent: raise ValueError('Resume must use original output directory')
    elif out.exists() and any(out.iterdir()):
        raise FileExistsError('Output directory is nonempty; resume or choose a new output directory')
    if start>=c['epochs']: raise ValueError('Already reached requested epochs')
    out.mkdir(parents=True,exist_ok=True)
    (out/'config.json').write_text(json.dumps(c,indent=2))
    (out/'environment.json').write_text(json.dumps({'torch':str(torch.__version__),'device':str(dev),'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name() if dev.type=='cuda' else None,'data_hash':data_hash},indent=2))
    logpath=out/'metrics.csv'
    # Drop log rows newer than the resumed epoch after an interrupted save.
    if a.resume and logpath.exists():
        with logpath.open() as f: old=list(csv.DictReader(f))
        with logpath.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['epoch','train_loss','val_loss','dice','iou','seconds']); w.writeheader()
            w.writerows(r for r in old if int(r['epoch'])<=start)
    with logpath.open('a',newline='') as f:
        writer=csv.writer(f)
        if f.tell()==0: writer.writerow(['epoch','train_loss','val_loss','dice','iou','seconds'])
        for epoch in range(start,c['epochs']):
            t=time.time(); model.train(); total=0.
            for x,y,_ in tqdm(tl,desc=f'Train {epoch+1}/{c["epochs"]}'):
                x=x.to(dev); y=y.to(dev); optimizer.zero_grad(set_to_none=True)
                with torch.autocast(device_type=dev.type,enabled=amp): pred=model(x); loss=loss_fn(pred,y)
                if not torch.isfinite(loss): raise RuntimeError('Non-finite training loss')
                scaler.scale(loss).backward(); scaler.step(optimizer); scaler.update()
                total+=loss.item()*x.size(0)
            model.eval(); vl_total=ds=js=0.
            with torch.inference_mode():
                for x,y,_ in vl:
                    x=x.to(dev); y=y.to(dev); pred=model(x)
                    vloss=loss_fn(pred,y)
                    if not torch.isfinite(vloss): raise RuntimeError('Non-finite validation loss')
                    d,j=scores(pred.sigmoid(),y,c['threshold'])
                    vl_total+=vloss.item()*x.size(0); ds+=d.sum().item(); js+=j.sum().item()
            dice=ds/len(val); iou=js/len(val)
            if dice>best:
                best=dice; stale=0; atomic_save(model.state_dict(),out/'best.pth')
            else: stale+=1
            atomic_save({'model':model.state_dict(),'optimizer':optimizer.state_dict(),'scaler':scaler.state_dict(),
                         'epoch':epoch,'best':best,'stale':stale,'config':c,'data_hash':data_hash,
                         'rng':torch.get_rng_state(),'loader_rng':gen.get_state(),
                         'cuda_rng':torch.cuda.get_rng_state_all() if dev.type=='cuda' else []},out/'last.ckpt')
            writer.writerow([epoch+1,total/len(train),vl_total/len(val),dice,iou,time.time()-t]); f.flush()
            print(f'epoch={epoch+1} dice={dice:.4f} iou={iou:.4f} best={best:.4f}',flush=True)
            if stale>=c['patience']:
                print('Early stopping'); break
    print(f'Finished. Best weights: {out/"best.pth"}')

if __name__=='__main__': main()
