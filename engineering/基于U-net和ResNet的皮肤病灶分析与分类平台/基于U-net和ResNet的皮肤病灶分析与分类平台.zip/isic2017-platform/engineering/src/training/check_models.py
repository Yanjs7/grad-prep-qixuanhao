"""Run from project root: python -m engineering.src.training.check_models"""
import torch
from ..models import UNet, ResNet18, resnet18


def main():
    torch.manual_seed(42)
    torch.set_num_threads(2)
    seg = UNet(base_channels=8)
    x = torch.randn(2, 3, 65, 67)
    logits = seg(x)
    assert logits.shape == (2, 1, 65, 67)
    loss = torch.nn.functional.binary_cross_entropy_with_logits(logits, torch.rand_like(logits))
    loss.backward()
    assert seg.inc[0].weight.grad is not None
    assert torch.isfinite(seg.inc[0].weight.grad).all()
    cls = resnet18(num_classes=3)
    scores = cls(torch.randn(2, 3, 64, 64))
    assert scores.shape == (2, 3)
    torch.nn.functional.cross_entropy(scores, torch.tensor([0, 2])).backward()
    assert torch.isfinite(cls.conv1.weight.grad).all()
    reference = ResNet18(1000)
    assert sum(p.numel() for p in reference.parameters()) == 11689512
    for model, inputs in [(seg, x), (cls, torch.randn(1, 3, 64, 64))]:
        model.eval()
        with torch.no_grad():
            output = model(inputs)
            assert torch.isfinite(output).all()
    print('PASS: segmentation shape (including odd sizes), classification shape, gradients, eval, ResNet18 parameter count.')


if __name__ == '__main__':
    main()
