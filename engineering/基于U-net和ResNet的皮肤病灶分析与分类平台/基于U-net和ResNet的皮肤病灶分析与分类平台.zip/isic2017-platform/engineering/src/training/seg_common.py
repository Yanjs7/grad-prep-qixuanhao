import json
import os
from pathlib import Path
import torch
from torch.nn import functional as F


def loss_fn(logits, target):
    p=logits.sigmoid(); dims=(1,2,3)
    dice=(2*(p*target).sum(dims)+1e-6)/(p.sum(dims)+target.sum(dims)+1e-6)
    return F.binary_cross_entropy_with_logits(logits,target)+(1-dice).mean()


def scores(prob, target, threshold=.5):
    p=prob>=threshold; y=target>.5; dims=(1,2,3)
    inter=(p&y).sum(dims).float(); total=p.sum(dims)+y.sum(dims)
    union=(p|y).sum(dims).float()
    return (2*inter+1e-6)/(total+1e-6),(inter+1e-6)/(union+1e-6)


def atomic_save(obj, path):
    path=Path(path); tmp=path.with_suffix(path.suffix+'.tmp')
    torch.save(obj,tmp); os.replace(tmp,path)


def config(path):
    c=json.loads(Path(path).read_text())
    if c['image_size']<32 or c['batch_size']<1 or c['epochs']<1 or not 0<c['threshold']<1:
        raise ValueError('Invalid size, batch size, epochs or threshold')
    return c
