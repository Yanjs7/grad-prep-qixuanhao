import argparse,csv,hashlib,io,json,zipfile
from pathlib import Path
from PIL import Image

def main():
 p=argparse.ArgumentParser();p.add_argument('--raw-root',required=True);p.add_argument('--output',required=True);a=p.parse_args()
 out=Path(a.output);out.mkdir(parents=True,exist_ok=True);reports={};seen={}
 # validation first: exclude training content duplicated in validation
 for split,stem,count in [('val','Validation',150),('train','Training',2000)]:
  root=Path(a.raw_root)/split
  with (root/f'ISIC-2017_{stem}_Part3_GroundTruth.csv').open() as f: rows=list(csv.DictReader(f))
  labels={}
  for r in rows:
   m=float(r['melanoma']);s=float(r['seborrheic_keratosis'])
   if (m,s) not in [(0,0),(1,0),(0,1)]:raise ValueError('Invalid class labels')
   if r['image_id'] in labels:raise ValueError('Duplicate label ID')
   labels[r['image_id']]=1 if m else 2 if s else 0
  records=[];excluded=[];folder=out/split;folder.mkdir(exist_ok=True)
  with zipfile.ZipFile(root/f'ISIC-2017_{stem}_Data.zip') as z:
   names={Path(n).stem:n for n in z.namelist() if n.lower().endswith('.jpg')}
   assert len(names)==count and names.keys()==labels.keys()
   for i,key in enumerate(sorted(names)):
    raw=z.read(names[key]);sha=hashlib.sha256(raw).hexdigest()
    if sha in seen:
     excluded.append({'id':key,'duplicate_of':seen[sha]});continue
    seen[sha]=key
    with Image.open(io.BytesIO(raw)) as im:
     im.load();size=im.size
     # Same RGB + PIL bilinear preprocessing as deployed classifier; cache losslessly.
     im.convert('RGB').resize((224,224),Image.Resampling.BILINEAR).save(folder/f'{key}.png')
    records.append({'id':key,'label':labels[key],'sha256':sha,'original_size':size})
    if i%200==0:print(split,i,flush=True)
  (out/f'{split}.json').write_text(json.dumps(records,indent=2))
  reports[split]={'count':len(records),'classes':[sum(r['label']==k for r in records) for k in range(3)],'excluded':excluded}
 (out/'report.json').write_text(json.dumps(reports,indent=2));print(reports)
if __name__=='__main__':main()
