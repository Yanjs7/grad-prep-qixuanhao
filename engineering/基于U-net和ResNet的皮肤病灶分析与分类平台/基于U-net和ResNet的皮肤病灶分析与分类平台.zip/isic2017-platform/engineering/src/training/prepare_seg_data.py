"""Prepare RGB images and Task 1 masks without extracting superpixel files."""
import argparse
import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from PIL import Image
import numpy as np

NAMES = {'train': ('Training', 2000), 'val': ('Validation', 150), 'test': ('Test_v2', 600)}


def members(z, mask):
    result = {}
    for info in z.infolist():
        name = Path(info.filename).name
        match = name.endswith('_segmentation.png') if mask else name.lower().endswith('.jpg')
        if info.is_dir() or not match or not name.startswith('ISIC_'):
            continue
        key = name.removesuffix('_segmentation.png') if mask else Path(name).stem
        if key in result:
            raise ValueError(f'Duplicate ID in archive: {key}')
        result[key] = info
    return result


def prepare(raw, out, splits, expected=True):
    report_path = out/'preparation_report.json'
    report = json.loads(report_path.read_text()) if report_path.exists() else {}
    seen = set()
    for previous in out.glob('*/manifest.json'):
        seen.update(row['id'] for row in json.loads(previous.read_text()))
    for split in splits:
        stem, count = NAMES[split]
        dst = out / split
        if dst.exists():
            raise FileExistsError(f'{dst} exists; use a new output root or remove only an incomplete generated split.')
        image_zip = raw / split / f'ISIC-2017_{stem}_Data.zip'
        mask_zip = raw / split / f'ISIC-2017_{stem}_Part1_GroundTruth.zip'
        rows = []
        with zipfile.ZipFile(image_zip) as iz, zipfile.ZipFile(mask_zip) as mz:
            ims, masks = members(iz, False), members(mz, True)
            if ims.keys() != masks.keys():
                raise ValueError(f'{split}: image/mask ID sets differ')
            if expected and len(ims) != count:
                raise ValueError(f'{split}: expected {count}, got {len(ims)}')
            if seen.intersection(ims):
                raise ValueError('Duplicate ID across requested splits')
            seen.update(ims)
            for folder in ['images', 'masks']:
                (dst / folder).mkdir(parents=True)
            for i, key in enumerate(sorted(ims)):
                paths = [dst/'images'/f'{key}.jpg', dst/'masks'/f'{key}_segmentation.png']
                for z, item, path in [(iz, ims[key], paths[0]), (mz, masks[key], paths[1])]:
                    # Reading each used member to EOF also verifies its ZIP CRC.
                    with z.open(item) as src, path.open('wb') as target:
                        shutil.copyfileobj(src, target)
                with Image.open(paths[0]) as image, Image.open(paths[1]) as mask:
                    image.load(); mask.load()
                    if image.size != mask.size:
                        raise ValueError(f'Size mismatch: {key}')
                    values = np.asarray(mask.convert('L'))
                    if not set(np.unique(values)).issubset({0, 1, 255}):
                        raise ValueError(f'Non-binary mask: {key}')
                    width, height = image.size
                    ratio = float((values > 0).mean())
                rows.append({'id': key, 'width': width, 'height': height, 'lesion_ratio': ratio,
                             'image_sha256': hashlib.sha256(paths[0].read_bytes()).hexdigest(),
                             'mask_sha256': hashlib.sha256(paths[1].read_bytes()).hexdigest()})
                if (i+1) % 100 == 0:
                    print(f'{split}: {i+1}/{len(ims)}', flush=True)
        (dst/'manifest.json').write_text(json.dumps(rows, indent=2))
        report[split] = {'count': len(rows), 'empty_masks': sum(r['lesion_ratio']==0 for r in rows)}
    (out/'preparation_report.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw-root', type=Path, default=Path('data/isic2017/raw'))
    p.add_argument('--output-root', type=Path, default=Path('data/isic2017/segmentation'))
    p.add_argument('--splits', nargs='+', choices=list(NAMES), default=['train','val'])
    a=p.parse_args(); prepare(a.raw_root, a.output_root, a.splits)

if __name__ == '__main__': main()
