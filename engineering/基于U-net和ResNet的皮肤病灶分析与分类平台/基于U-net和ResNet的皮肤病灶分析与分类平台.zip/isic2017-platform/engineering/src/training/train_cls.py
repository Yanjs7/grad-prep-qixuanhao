import argparse,csv,json,os,time
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset,DataLoader
from sklearn.metrics import f1_score,confusion_matrix,classification_report,roc_auc_score
from ..models.resnet18 import resnet18

class Images(Dataset):
 def __init__(self,root,split,limit=0):
  self.root=Path(root);self.split=split;self.rows=json.loads((self.root/f'{split}.json').read_text());self.rows=self.rows[:limit] if limit else self.rows
 def __len__(self):return len(self.rows)
 def __getitem__(self,i):
  r=self.rows[i]
  with Image.open(self.root/self.split/(r['id']+'.png')) as source: im=source.convert('RGB')
  if self.split=='train':
   if torch.rand(())<.5:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
   if torch.rand(())<.5:im=im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
  x=np.array(im,dtype=np.float32)/255
  x=(x-np.array([.485,.456,.406],np.float32))/np.array([.229,.224,.225],np.float32)
  return torch.from_numpy(x.transpose(2,0,1).copy()),r['label']

def save(obj,path):
 tmp=path.with_suffix('.tmp');torch.save(obj,tmp);os.replace(tmp,path)

def main():
 p=argparse.ArgumentParser();p.add_argument('--data',default='data/classification');p.add_argument('--output',default='outputs/resnet18');p.add_argument('--epochs',type=int,default=50);p.add_argument('--workers',type=int,default=4);p.add_argument('--batch-size',type=int,default=32);p.add_argument('--device',default='cuda');p.add_argument('--limit',type=int,default=0);p.add_argument('--resume');p.add_argument('--random-init',action='store_true',help='Tests only; production uses ImageNet pretrained weights');a=p.parse_args()
 torch.manual_seed(42);torch.set_num_threads(4);dev=torch.device(a.device)
 if dev.type=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 out=Path(a.output)
 if not a.resume and out.exists() and any(out.iterdir()):raise RuntimeError('Output is nonempty; use resume or a new output')
 out.mkdir(parents=True,exist_ok=True)
 tr=Images(a.data,'train',a.limit);va=Images(a.data,'val',a.limit)
 counts=np.bincount([r['label'] for r in tr.rows],minlength=3)
 if (counts==0).any():raise ValueError('Training split must include all three classes')
 weights=torch.tensor(len(tr)/(3*counts),dtype=torch.float32,device=dev)
 gen=torch.Generator().manual_seed(42)
 tl=DataLoader(tr,batch_size=a.batch_size,shuffle=True,num_workers=a.workers,generator=gen,pin_memory=dev.type=='cuda')
 vl=DataLoader(va,batch_size=a.batch_size,num_workers=a.workers)
 model=resnet18(pretrained=not a.random_init and not a.resume).to(dev)
 opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=1e-4);scaler=torch.amp.GradScaler('cuda',enabled=dev.type=='cuda')
 criterion=torch.nn.CrossEntropyLoss(weight=weights);start=0;best=-1;stale=0
 import hashlib
 fingerprint=hashlib.sha256(b''.join((Path(a.data)/f'{s}.json').read_bytes() for s in ['train','val'])).hexdigest()
 if a.resume:
  ck=torch.load(a.resume,map_location='cpu',weights_only=True)
  if ck['fingerprint']!=fingerprint:raise ValueError('Data changed')
  for key in ['batch_size','limit','workers','random_init']:
   if ck['args'][key]!=vars(a)[key]:raise ValueError('Resume mismatch: '+key)
  model.load_state_dict(ck['model']);opt.load_state_dict(ck['optimizer']);scaler.load_state_dict(ck['scaler']);start=ck['epoch']+1;best=ck['best'];stale=ck['stale'];torch.set_rng_state(ck['rng']);gen.set_state(ck['generator'])
  if dev.type=='cuda' and ck['cuda_rng']:torch.cuda.set_rng_state_all(ck['cuda_rng'])
  if out.resolve()!=Path(a.resume).resolve().parent:raise ValueError('Resume into original directory')
 if start>=a.epochs:raise ValueError('Already reached epochs')
 config=dict(vars(a),class_names=['nevus','melanoma','seborrheic_keratosis'],image_size=224,version='resnet18-isic2017-v1',class_weights=weights.cpu().tolist(),fingerprint=fingerprint)
 (out/'config.json').write_text(json.dumps(config,indent=2))
 (out/'environment.json').write_text(json.dumps({'torch':str(torch.__version__),'gpu':torch.cuda.get_device_name() if dev.type=='cuda' else None}))
 log=out/'metrics.csv'
 if a.resume and log.exists():
  with log.open() as f:old=list(csv.DictReader(f))
  with log.open('w',newline='') as f:
   w=csv.DictWriter(f,fieldnames=['epoch','train_loss','val_loss','macro_f1','accuracy','seconds']);w.writeheader();w.writerows(r for r in old if int(r['epoch'])<=start)
 with log.open('a',newline='') as f:
  writer=csv.writer(f)
  if f.tell()==0:writer.writerow(['epoch','train_loss','val_loss','macro_f1','accuracy','seconds']);f.flush()
  for epoch in range(start,a.epochs):
   t=time.time();model.train();loss_sum=0
   for batch,(x,y) in enumerate(tl):
    x=x.to(dev);y=y.to(dev);opt.zero_grad(set_to_none=True)
    with torch.autocast(dev.type,enabled=dev.type=='cuda'): logits=model(x);loss=criterion(logits,y)
    if not torch.isfinite(loss):raise RuntimeError('Nonfinite loss')
    scaler.scale(loss).backward();scaler.step(opt);scaler.update();loss_sum+=loss.item()*len(y)
    if batch%20==0:print(f'epoch {epoch+1}/{a.epochs} batch {batch+1}/{len(tl)} loss {loss.item():.4f}',flush=True)
   model.eval();ys=[];ps=[];val_loss=0
   with torch.inference_mode():
    for x,y in vl:
     logits=model(x.to(dev));loss=torch.nn.functional.cross_entropy(logits,y.to(dev));prob=logits.softmax(1)
     if not torch.isfinite(prob).all():raise RuntimeError('Invalid validation probabilities')
     val_loss+=loss.item()*len(y);ys.extend(y.tolist());ps.extend(prob.cpu().tolist())
   pred=np.argmax(ps,axis=1);f1=float(f1_score(ys,pred,labels=[0,1,2],average='macro',zero_division=0));acc=float(np.mean(pred==ys))
   if f1>best:
    best=f1;stale=0;save(model.state_dict(),out/'best.pth')
    report=classification_report(ys,pred,labels=[0,1,2],output_dict=True,zero_division=0)
    report['confusion_matrix']=confusion_matrix(ys,pred,labels=[0,1,2]).tolist();report['epoch']=epoch+1
    report['auc_ovr']=[float(roc_auc_score(np.array(ys)==k,np.array(ps)[:,k])) if 0<sum(np.array(ys)==k)<len(ys) else None for k in range(3)]
    (out/'best_validation.json').write_text(json.dumps(report,indent=2))
   else:stale+=1
   save({'model':model.state_dict(),'optimizer':opt.state_dict(),'scaler':scaler.state_dict(),'epoch':epoch,'best':best,'stale':stale,'fingerprint':fingerprint,'args':vars(a),'rng':torch.get_rng_state(),'generator':gen.get_state(),'cuda_rng':torch.cuda.get_rng_state_all() if dev.type=='cuda' else []},out/'last.ckpt')
   writer.writerow([epoch+1,loss_sum/len(tr),val_loss/len(va),f1,acc,time.time()-t]);f.flush();print(f'epoch={epoch+1} macro_f1={f1:.4f} accuracy={acc:.4f} best={best:.4f}',flush=True)
   if stale>=10:print('Early stopping',flush=True);break
if __name__=='__main__':main()
