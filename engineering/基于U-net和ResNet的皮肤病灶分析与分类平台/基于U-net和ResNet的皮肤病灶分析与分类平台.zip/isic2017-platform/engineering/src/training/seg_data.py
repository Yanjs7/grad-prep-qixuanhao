import hashlib
import json
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset


class SegDataset(Dataset):
    def __init__(self, root, split, size=256, augment=False, limit=0):
        self.root = Path(root)/split
        self.rows = json.loads((self.root/'manifest.json').read_text())
        if limit: self.rows = self.rows[:limit]
        if not self.rows: raise ValueError(f'Empty split: {split}')
        self.size, self.augment = size, augment

    def __len__(self): return len(self.rows)

    def __getitem__(self, index):
        key = self.rows[index]['id']
        with Image.open(self.root/'images'/f'{key}.jpg') as src:
            im = src.convert('RGB').resize((self.size,self.size), Image.Resampling.BILINEAR)
        with Image.open(self.root/'masks'/f'{key}_segmentation.png') as src:
            mask = src.convert('L').resize((self.size,self.size), Image.Resampling.NEAREST)
        if self.augment:
            if torch.rand(()) < .5:
                im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT); mask=mask.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            if torch.rand(()) < .5:
                im=im.transpose(Image.Transpose.FLIP_TOP_BOTTOM); mask=mask.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
            k=int(torch.randint(0,4,()).item())
            if k:
                method=[Image.Transpose.ROTATE_90,Image.Transpose.ROTATE_180,Image.Transpose.ROTATE_270][k-1]
                im=im.transpose(method); mask=mask.transpose(method)
        x=torch.from_numpy(np.array(im,dtype=np.float32).transpose(2,0,1).copy())/255
        y=torch.from_numpy((np.array(mask)>0).astype(np.float32)[None])
        return x,y,key


def fingerprint(root, splits=('train','val')):
    h=hashlib.sha256(); ids=set(); hashes=set()
    for split in splits:
        content=(Path(root)/split/'manifest.json').read_bytes()
        rows=json.loads(content)
        current={r['id'] for r in rows}; current_hash={r['image_sha256'] for r in rows}
        if len(current)!=len(rows) or ids & current or hashes & current_hash:
            raise ValueError('Duplicate images/IDs in or across splits; inspect manifests')
        ids.update(current); hashes.update(current_hash); h.update(content)
    return h.hexdigest()
