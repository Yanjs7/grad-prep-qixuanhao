const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels=['黑素细胞痣','黑色素瘤','脂溢性角化病'];
let health, selectedFile, previewURL, result, page=1, busy=false, selectionToken=0;
const route=location.pathname==='/history'?'history':location.pathname==='/models'?'models':location.pathname.startsWith('/records/')?'detail':'analysis';
document.querySelectorAll('.page').forEach(el=>el.hidden=el.id!==route);
document.querySelector(`[data-nav="${route==='detail'?'history':route}"]`)?.classList.add('active');
$('#breadcrumb').textContent={analysis:'图像分析',history:'历史记录',models:'模型与项目',detail:'分析详情'}[route];
function error(message){$('#error').textContent=message;$('#error').hidden=false;setTimeout(()=>$('#error').hidden=true,8000)}
async function request(url,options){const r=await fetch(url,options);if(!r.ok){let data;try{data=await r.json()}catch{}throw new Error(typeof data?.detail==='string'?data.detail:`请求失败（${r.status}）`)}return r.json()}
function when(s){return new Date(s).toLocaleString('zh-CN')}
function stats(r){const p=r.prediction;return `${p?`<div class="result-label">分类模型预测</div><div class="prediction">${esc(p.label)}</div>${p.probabilities.map((v,i)=>`<div class="prob-row"><span>${labels[i]}</span><b>${(v*100).toFixed(1)}%</b></div><div class="bar"><span style="width:${v*100}%"></span></div>`).join('')}`:'<div class="pending">分类模型未就绪<br><small>当前结果仅包含 U-Net 病灶分割。</small></div>'}<div class="stats"><div class="stat"><strong>${(r.segmentation.lesion_ratio*100).toFixed(2)}<small>%</small></strong><small>病灶面积占比</small></div><div class="stat"><strong>${(r.inference_ms/1000).toFixed(2)}<small>s</small></strong><small>推理与预处理耗时</small></div><div class="stat"><strong>${r.segmentation.lesion_pixels.toLocaleString()}</strong><small>病灶像素</small></div><div class="stat"><strong style="font-size:15px">${r.image.width} × ${r.image.height}</strong><small>图像尺寸</small></div></div><div class="result-actions"><a class="button primary" href="/api/records/${r.id}/export">下载结果 ZIP</a><a class="button secondary" href="/records/${r.id}">查看详情 ↗</a></div>`}
async function init(){try{health=await request('/api/health');const ready=health.models.segmentation.ready;$('#health-dot').classList.toggle('ready',ready);$('#health-text').textContent=ready?'分割模型可用':'服务在线 · 模型待配置';$('#mini-models').innerHTML=Object.entries(health.models).map(([k,v])=>`<div class="model-row"><b>${k==='segmentation'?'U-Net':'ResNet18'}</b><span>${v.ready?'● 可用':'○ 未就绪'}</span></div>`).join('');$('#model-cards').innerHTML=Object.entries(health.models).map(([k,v],i)=>`<article class="card model-card"><span class="tag">${i?'CLASSIFICATION':'SEGMENTATION'}</span><h2>${i?'ResNet18':'U-Net'}</h2><p>${i?'三类病灶分类 · ImageNet 骨干迁移学习':'病灶像素级分割 · 编码器与解码器跳跃连接'}</p><div class="model-state"><span class="badge">${v.ready?'已就绪':'待配置'}</span><p>${esc(v.message)}</p><p>版本：${esc(v.version||'—')} · 推理设备：CPU</p></div></article>`).join('');updateButton()}catch(e){$('#health-text').textContent='服务连接失败';error(e.message)}if(route==='history')loadHistory();if(route==='detail')loadDetail()}
function updateButton(){$('#analyze').disabled=!selectedFile||!health?.models.segmentation.ready||busy;$('#reset').disabled=busy||!selectedFile;$('#analyze').textContent=busy?'正在分析…':'开始分析 →';$('#analyze').classList.toggle('busy',busy)}
async function selectFile(file){
  if(busy||!file)return;
  if(!['image/jpeg','image/png'].includes(file.type)){error('请选择 JPG 或 PNG 图片');return}
  if(file.size>20*1024*1024){error('图片不能超过 20MB');return}
  const token=++selectionToken;
  const url=URL.createObjectURL(file);
  const probe=new Image();
  let valid=false;
  try {
    await new Promise((resolve,reject)=>{probe.onload=resolve;probe.onerror=reject;probe.src=url});
    if(probe.naturalWidth*probe.naturalHeight>25000000)throw new Error('图片不能超过 2500 万像素');
    valid=true;
  } catch(e) {
    if(token===selectionToken)error(e instanceof Error?e.message:'图片损坏或无法解码');
  }
  if(!valid||token!==selectionToken||busy){URL.revokeObjectURL(url);return}
  if(previewURL)URL.revokeObjectURL(previewURL);
  selectedFile=file;previewURL=url;result=null;
  $('#base-image').src=previewURL;
  $('#overlay-image').hidden=true;
  $('#overlay-image').style.opacity='1';
  $('#opacity').value='100';
  $('#viewer').hidden=false;$('#dropzone').hidden=true;
  $('#filename').textContent=file.name;
  $('#image-meta').textContent=`${probe.naturalWidth} × ${probe.naturalHeight} px · ${(file.size/1024/1024).toFixed(2)} MB`;
  $('#result-body').hidden=true;$('#result-body').innerHTML='';
  $('#result-empty').hidden=false;$('#result-status').textContent='待分析';
  $('#zoom').value=100;$('#image-layer').style.transform='scale(1)';
  document.querySelectorAll('.steps span').forEach((el,i)=>el.classList.toggle('selected',i===0));
  view('original');
  document.querySelectorAll('[data-view]').forEach(b=>b.disabled=b.dataset.view!=='original');
  updateButton();
  if(health&&!health.models.segmentation.ready)error('图片预览已就绪。分割模型尚未配置，暂不能开始分析。');
}
$('#file-input').onchange=e=>selectFile(e.target.files[0]);$('#dropzone').onclick=()=>$('#file-input').click();$('#dropzone').onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();$('#file-input').click()}};
$('#dropzone').ondragover=e=>{e.preventDefault();$('#dropzone').classList.add('drag')};$('#dropzone').ondragleave=()=>$('#dropzone').classList.remove('drag');$('#dropzone').ondrop=e=>{e.preventDefault();$('#dropzone').classList.remove('drag');selectFile(e.dataTransfer.files[0])};$('#reset').onclick=()=>{$('#file-input').value='';$('#file-input').click()};
function view(kind){document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===kind));$('#base-image').src=result?result.files[kind==='mask'?'mask':'original']:previewURL;$('#overlay-image').hidden=kind!=='overlay';if(result)$('#overlay-image').src=result.files.overlay;$('#opacity-control').hidden=kind!=='overlay'}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>view(b.dataset.view));$('#zoom').oninput=e=>$('#image-layer').style.transform=`scale(${e.target.value/100})`;$('#opacity').oninput=e=>$('#overlay-image').style.opacity=e.target.value/100;
$('#analyze').onclick=async()=>{if(!selectedFile||busy)return;busy=true;updateButton();$('#result-status').textContent='处理中';const data=new FormData();data.append('file',selectedFile);try{result=await request('/api/analyze',{method:'POST',body:data});$('#result-empty').hidden=true;$('#result-body').hidden=false;$('#result-body').innerHTML=stats(result);$('#result-status').textContent='已完成';$('#image-meta').textContent=`${result.image.width} × ${result.image.height} px`;document.querySelectorAll('[data-view]').forEach(b=>b.disabled=false);view('overlay');document.querySelectorAll('.steps span').forEach(s=>s.classList.add('selected'))}catch(e){error(e.message);$('#result-status').textContent='分析失败'}finally{busy=false;updateButton()}};
async function loadHistory(){try{const params=new URLSearchParams({page:String(page),page_size:'12',q:$('#search').value,date:$('#date-filter').value,tz_offset:String($('#date-filter').value?new Date($('#date-filter').value+'T00:00:00').getTimezoneOffset():new Date().getTimezoneOffset())});if($('#class-filter').value!=='')params.set('class_id',$('#class-filter').value);const data=await request('/api/records?'+params);$('#record-grid').innerHTML=data.items.length?data.items.map(r=>`<a class="card record-card" href="/records/${r.id}"><img src="${r.files.overlay}" alt="病灶叠加图" loading="lazy"><div class="info"><h3>${esc(r.filename)}</h3><p>${when(r.created_at)}</p><span class="tag">${esc(r.prediction?.label||'仅分割')} · ${(r.segmentation.lesion_ratio*100).toFixed(1)}%</span></div></a>`).join(''):'<div class="card blank"><h2>暂无分析记录</h2><p>完成一次图像分析后，结果会自动保存在这里。</p><br><a class="button primary" href="/">开始分析 →</a></div>';$('#page-info').textContent=`第 ${page} 页 · 共 ${data.total} 条`;$('#prev').disabled=page===1;$('#next').disabled=page*12>=data.total}catch(e){error(e.message)}}
$('#search-button').onclick=()=>{page=1;loadHistory()};$('#search').onkeydown=e=>{if(e.key==='Enter'){page=1;loadHistory()}};$('#prev').onclick=()=>{page--;loadHistory()};$('#next').onclick=()=>{page++;loadHistory()};
async function loadDetail(){try{const r=await request('/api/records/'+encodeURIComponent(location.pathname.split('/').pop()));$('#detail-content').innerHTML=`<div class="page-head"><div><div class="eyebrow">ANALYSIS DETAIL</div><h1>${esc(r.filename)}</h1><p>${when(r.created_at)} · ${esc(r.id.slice(0,8))}</p></div><button class="button secondary" onclick="window.print()">打印报告</button></div><div class="analysis-grid"><article class="card"><div class="card-title"><h2>图像与分割结果</h2></div><div class="detail-images"><label>原图<img src="${r.files.original}" alt="原图"></label><label>叠加图<img src="${r.files.overlay}" alt="叠加图"></label><label>二值掩码<img src="${r.files.mask}" alt="病灶掩码"></label></div></article><article class="card"><div class="card-title"><h2>结果摘要</h2></div><div style="padding:20px">${stats(r)}<p style="font-size:11px;margin-top:20px">模型版本：${esc(Object.entries(r.model_versions).map(([k,v])=>`${k}: ${v}`).join(' / '))}</p></div></article></div><div class="notice">本报告为模型预测，仅供学习与研究，不作为临床诊断依据。</div>`}catch(e){$('#detail-content').innerHTML='<div class="card blank"><h2>记录无法读取</h2><p>请检查记录链接或返回历史记录。</p></div>';error(e.message)}}
init();
