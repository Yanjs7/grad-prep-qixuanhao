import io,json,tempfile,zipfile,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from pathlib import Path
from PIL import Image
import torch
from fastapi.testclient import TestClient
from engineering.src.backend import main as m
from engineering.src.models import UNet
m.RUNTIME=Path(tempfile.mkdtemp());m.ARTIFACTS=Path(tempfile.mkdtemp())
with TestClient(m.app) as c:
 for page in ['/','/history','/models','/records/unknown','/static/app.js','/static/style.css']:
  assert c.get(page).status_code==200,page
 assert not c.get('/api/health').json()['models']['segmentation']['ready']
 assert c.post('/api/analyze',files={'file':('a.png',b'x','image/png')}).status_code==503
# Isolated synthetic weights ONLY for test, never shipped as trained models.
torch.save(UNet(base_channels=2).state_dict(),m.ARTIFACTS/'segmentation.pth')
(m.ARTIFACTS/'segmentation_config.json').write_text(json.dumps({'base_channels':2,'image_size':32,'threshold':.5,'version':'TEST-ONLY'}))
b=io.BytesIO();Image.new('RGB',(80,50),(150,80,60)).save(b,format='PNG')
with TestClient(m.app) as c:
 assert c.get('/api/health').json()['models']['segmentation']['ready']
 assert c.post('/api/analyze',files={'file':('bad.jpg',b'invalid','image/jpeg')}).status_code==400
 r=c.post('/api/analyze',files={'file':('sample.png',b.getvalue(),'image/png')});assert r.status_code==200,r.text
 data=r.json();assert data['prediction'] is None and data['image']=={'width':80,'height':50}
 rid=data['id']; assert c.get('/api/records').json()['total']==1
 assert c.get('/api/records?q=sample').json()['total']==1
 assert c.get('/api/records?q=missing').json()['total']==0
 for kind in ['original','mask','overlay']:
  img=Image.open(io.BytesIO(c.get(f'/api/records/{rid}/files/{kind}').content));assert img.size==(80,50)
 assert c.get(f'/api/records/{rid}/files/secret').status_code==404
 z=zipfile.ZipFile(io.BytesIO(c.get(f'/api/records/{rid}/export').content));assert len(z.namelist())==4
with TestClient(m.app) as c: assert c.get('/api/records').json()['total']==1
print('PASS: pages, missing-model state, invalid upload, analysis, history/filter, original-size files, export, restart persistence')
