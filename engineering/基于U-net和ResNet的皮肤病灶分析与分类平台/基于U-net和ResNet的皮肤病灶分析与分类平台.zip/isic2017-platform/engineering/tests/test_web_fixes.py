import sys,tempfile,json,sqlite3,logging,io
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
from engineering.src.backend import main as m
from fastapi.testclient import TestClient
from unittest.mock import patch
m.RUNTIME=Path(tempfile.mkdtemp());m.ARTIFACTS=Path(tempfile.mkdtemp())
with TestClient(m.app) as c:
 with m.db() as conn:
  conn.execute('INSERT INTO records VALUES (?,?,?,?,?)',('a','2026-09-19T18:00:00+00:00','test',None,json.dumps({'id':'a'})))
 try: conn.execute('SELECT 1'); raise AssertionError('connection leaked')
 except sqlite3.ProgrammingError: pass
 assert c.get('/api/records?date=2026-09-20&tz_offset=-480').json()['total']==1
 assert c.get('/api/records?date=2026-09-19&tz_offset=-480').json()['total']==0
 assert c.get('/api/records?date=invalid').status_code==422
 m.models['segmentation']=(None,{})
 with patch.object(m.Image,'open',side_effect=RuntimeError('synthetic internal failure')),patch.object(logging.Logger,'exception') as log:
  r=c.post('/api/analyze',files={'file':('a.png',b'x','image/png')})
  assert r.status_code==500 and '请求编号' in r.json()['detail']
  assert log.call_count==1
print('PASS: connections closed, local date boundaries, invalid date, error logging and request IDs')
