#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
PYTHON="${ISIC_PYTHON:-.venv/bin/python}"
if [ ! -x "$PYTHON" ]; then echo "请先按 项目启动说明.md 安装环境，或设置 ISIC_PYTHON。"; exit 1; fi
exec "$PYTHON" -m uvicorn engineering.src.backend.main:app --host 127.0.0.1 --port "${PORT:-8765}"
