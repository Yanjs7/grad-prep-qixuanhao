"""Local, offline FIVES evaluation and HTML reporting."""
import csv
import html
import json
from pathlib import Path

import numpy as np
import torch
from PIL import Image


def write_csv(path, rows):
    if rows:
        with Path(path).open('w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)


def metrics(tp, fp, fn, tn):
    def ratio(a, b):
        return a / b if b else None
    return dict(dice=ratio(2*tp, 2*tp+fp+fn), iou=ratio(tp, tp+fp+fn),
                precision=ratio(tp, tp+fp), sensitivity=ratio(tp, tp+fn),
                specificity=ratio(tn, tn+fp), accuracy=ratio(tp+tn, tp+fp+fn+tn))


@torch.inference_mode()
def evaluate_binary(model, loader, device, amp=False, output=None):
    """Image-macro and pooled-pixel metrics, at loader resolution, whole image."""
    was_training = model.training
    model.eval()
    rows = []
    if output:
        output = Path(output)
        (output / 'predictions').mkdir(parents=True, exist_ok=True)
        (output / 'examples').mkdir(exist_ok=True)
    try:
        for batch in loader:
            images = batch['image'].to(device, dtype=torch.float32)
            with torch.autocast(device.type, enabled=amp and device.type == 'cuda'):
                logits = model(images)
            if not torch.isfinite(logits).all():
                raise FloatingPointError('Non-finite evaluation predictions; metrics/report would be invalid')
            pred = (logits[:, 0].sigmoid() > 0.5 if model.n_classes == 1 else logits.argmax(1) == 1).cpu().numpy()
            masks = batch['mask'].numpy()
            for i, (p, target) in enumerate(zip(pred, masks)):
                t = target == 1
                tp, fp, fn, tn = [int(x.sum()) for x in (p&t, p&~t, ~p&t, ~p&~t)]
                name = batch['name'][i]
                rows.append(dict(name=name, tp=tp, fp=fp, fn=fn, tn=tn, **metrics(tp, fp, fn, tn)))
                if output:
                    Image.fromarray(p.astype('uint8')*255).save(output/'predictions'/f'{name}.png')
                    if len(rows) <= 6:
                        rgb = (batch['image'][i].permute(1, 2, 0).numpy()*255).clip(0, 255).astype('uint8')
                        truth = np.repeat((t.astype('uint8')*255)[..., None], 3, axis=2)
                        predicted = np.repeat((p.astype('uint8')*255)[..., None], 3, axis=2)
                        Image.fromarray(np.concatenate([rgb, truth, predicted], axis=1)).save(output/'examples'/f'{name}.png')
        if not rows:
            raise ValueError('Evaluation dataset is empty')
        totals = {k:sum(r[k] for r in rows) for k in ['tp','fp','fn','tn']}
        keys = metrics(**totals)
        macro = {k:float(np.mean([r[k] for r in rows if r[k] is not None]))
                 if any(r[k] is not None for r in rows) else None for k in keys}
        return dict(count=len(rows), macro=macro, pooled=metrics(**totals), confusion=totals), rows
    finally:
        model.train(was_training)


def generate_report(output, config, history, summary, rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    output = Path(output)
    write_csv(output/'test_per_image.csv', rows)
    (output/'test_summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot([r['epoch'] for r in history], [r['train_loss'] for r in history])
    axes[0].set(xlabel='Epoch', ylabel='Training loss')
    axes[1].plot([r['epoch'] for r in history], [r['val_dice'] for r in history])
    axes[1].set(xlabel='Epoch', ylabel='Validation Dice', ylim=(0, 1))
    fig.tight_layout(); fig.savefig(output/'curves.png', dpi=150); plt.close(fig)
    names = dict(dice='Dice / F1', iou='IoU', precision='精确率', sensitivity='敏感度 / Recall', specificity='特异度', accuracy='像素准确率')
    def fmt(v): return '未定义' if v is None else f'{v:.6f}'
    table = ''.join(f'<tr><td>{label}</td><td>{fmt(summary["macro"][k])}</td><td>{fmt(summary["pooled"][k])}</td></tr>' for k,label in names.items())
    examples = ''.join(f'<img src="examples/{html.escape(p.name)}">' for p in sorted((output/'examples').glob('*.png')))
    page = f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>FIVES U-Net 训练报告</title>
    <style>body{{font:16px system-ui;max-width:1100px;margin:40px auto;padding:20px;line-height:1.6}}table{{border-collapse:collapse}}td,th{{border:1px solid #ccc;padding:10px}}img{{max-width:100%;margin:15px 0}}pre{{white-space:pre-wrap;background:#f4f4f4;padding:20px}}</style>
    <h1>FIVES U-Net 训练与测试报告</h1>
    <p>完成 {len(history)} 轮。按验证集逐图平均 Dice 选择最佳模型：第 {config['best_epoch']} 轮，Dice={config['best_val_dice']:.6f}。独立测试集共 {summary['count']} 张。</p>
    <h2>训练曲线</h2><img src="curves.png">
    <h2>最佳模型的测试集结果</h2><table><tr><th>指标</th><th>逐图平均</th><th>全体像素汇总</th></tr>{table}</table>
    <p>混淆计数：{html.escape(str(summary['confusion']))}</p>
    <p>血管为正类；二输出模型使用 argmax，单输出使用 sigmoid &gt; 0.5。指标在缩放后的整幅图像上计算，包含视野外背景；不是原始分辨率或视野内指标。零分母记为未定义，逐图均值忽略未定义值。未计算 ROC-AUC / PR-AUC。测试集只在训练完成后评估，不用于选模型。</p>
    <h2>分割示例</h2><p>按文件名排序的前六张；从左到右：原图、真实标注、预测。全部缩放分辨率预测保存在 predictions/。</p>{examples}
    <h2>配置与运行信息</h2><pre>{html.escape(json.dumps(config, indent=2, ensure_ascii=False))}</pre>
    <p>history.csv：逐轮训练记录；test_per_image.csv：逐图指标和混淆计数；test_summary.json：汇总指标；splits.json：训练/验证划分。单次运行结果不包含多随机种子置信区间。</p></html>'''
    (output/'report.html').write_text(page, encoding='utf-8')
