import json
import time
from datetime import datetime
import numpy as np
from utils.reporting import evaluate_binary, generate_report, write_csv
import argparse
import logging
import os
import random
import sys
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
import torchvision.transforms.functional as TF
from pathlib import Path
from torch import optim
from torch.utils.data import DataLoader, random_split
from tqdm import tqdm

import wandb
from evaluate import evaluate
from unet import UNet
from utils.data_loading import BasicDataset, CarvanaDataset
from utils.dice_score import dice_loss

project_root = Path(__file__).resolve().parent.parent
dir_img = project_root / 'data/FIVES/train/Original'
dir_mask = project_root / 'data/FIVES/train/Ground truth'
dir_checkpoint = project_root / 'checkpoints'


def train_model(
        model,
        device,
        epochs: int = 20,
        batch_size: int = 1,
        learning_rate: float = 1e-5,
        val_percent: float = 0.1,
        save_checkpoint: bool = True,
        img_scale: float = 0.5,
        amp: bool = False,
        weight_decay: float = 1e-8,
        momentum: float = 0.999,
        gradient_clipping: float = 1.0,
):
    if epochs < 1 or model.n_classes not in (1, 2):
        raise ValueError('Use epochs >= 1 and classes 1 or 2 for FIVES')
    amp = amp and device.type == 'cuda'
    started = time.monotonic()
    run_dir = dir_checkpoint / datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    run_dir.mkdir(parents=True)
    logging.info(f'Run output: {run_dir}')
    test_root = project_root / 'data/FIVES/test'
    for folder in [test_root / 'Original', test_root / 'Ground truth']:
        if not folder.is_dir():
            raise FileNotFoundError(f'Required for final report: {folder}')
    history, best_score, best_epoch = [], -1.0, 0
    # 1. Create dataset
    dataset = BasicDataset(dir_img, dir_mask, img_scale)
    if len(dataset.mask_values) != 2:
        raise ValueError(f"FIVES requires two mask values, found {dataset.mask_values}")

    # 2. Split into train / validation partitions
    n_val = int(len(dataset) * val_percent)
    n_train = len(dataset) - n_val
    if n_val < 1 or n_train < 1:
        raise ValueError("Training and validation splits must both contain images")
    train_set, val_set = random_split(dataset, [n_train, n_val], generator=torch.Generator().manual_seed(0))

    (run_dir / 'splits.json').write_text(json.dumps({
        'train': [dataset.ids[i] for i in train_set.indices],
        'validation': [dataset.ids[i] for i in val_set.indices],
        'seed': 0}, indent=2))
    # 3. Create data loaders
    loader_args = dict(batch_size=batch_size, num_workers=0, pin_memory=device.type == 'cuda')
    train_loader = DataLoader(train_set, shuffle=True, **loader_args)
    val_loader = DataLoader(val_set, shuffle=False, drop_last=False, **loader_args)

    # (Initialize logging)
    experiment = wandb.init(project='U-Net-FIVES', mode=os.environ.get('WANDB_MODE', 'disabled'))
    experiment.config.update(
        dict(epochs=epochs, batch_size=batch_size, learning_rate=learning_rate,
             val_percent=val_percent, save_checkpoint=save_checkpoint, img_scale=img_scale, amp=amp)
    )

    logging.info(f'''Starting training:
        Epochs:          {epochs}
        Batch size:      {batch_size}
        Learning rate:   {learning_rate}
        Training size:   {n_train}
        Validation size: {n_val}
        Checkpoints:     {save_checkpoint}
        Device:          {device.type}
        Images scaling:  {img_scale}
        Mixed Precision: {amp}
    ''')

    # 4. Set up the optimizer, the loss, the learning rate scheduler and the loss scaling for AMP
    optimizer = optim.RMSprop(model.parameters(),
                              lr=learning_rate, weight_decay=weight_decay, momentum=momentum, foreach=True)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=5)  # goal: maximize Dice score
    grad_scaler = torch.amp.GradScaler('cuda', enabled=amp and device.type == 'cuda')
    criterion = nn.CrossEntropyLoss() if model.n_classes > 1 else nn.BCEWithLogitsLoss()
    global_step = 0

    # 5. Begin training
    for epoch in range(1, epochs + 1):
        model.train()
        epoch_started = time.monotonic()
        epoch_loss = 0
        epoch_lr = optimizer.param_groups[0]["lr"]
        with tqdm(total=n_train, desc=f'Epoch {epoch}/{epochs}', unit='img') as pbar:
            for batch in train_loader:
                images, true_masks = batch['image'], batch['mask']

                assert images.shape[1] == model.n_channels, \
                    f'Network has been defined with {model.n_channels} input channels, ' \
                    f'but loaded images have {images.shape[1]} channels. Please check that ' \
                    'the images are loaded correctly.'

                images = images.to(device=device, dtype=torch.float32, memory_format=torch.channels_last)
                true_masks = true_masks.to(device=device, dtype=torch.long)

                with torch.autocast(device.type if device.type != 'mps' else 'cpu', enabled=amp):
                    masks_pred = model(images)
                # Keep probability and loss calculations in float32 under AMP.
                with torch.autocast(device.type, enabled=False):
                    masks_pred = masks_pred.float()
                    if not torch.isfinite(masks_pred).all():
                        raise FloatingPointError(f'Non-finite logits at epoch {epoch}, step {global_step}; rerun without --amp')
                    if model.n_classes == 1:
                        loss = criterion(masks_pred.squeeze(1), true_masks.float())
                        loss += dice_loss(F.sigmoid(masks_pred.squeeze(1)), true_masks.float(), multiclass=False)
                    else:
                        loss = criterion(masks_pred, true_masks)
                        loss += dice_loss(
                            F.softmax(masks_pred, dim=1).float(),
                            F.one_hot(true_masks, model.n_classes).permute(0, 3, 1, 2).float(),
                            multiclass=True
                        )

                if not torch.isfinite(loss):
                    raise FloatingPointError(f'Non-finite loss at epoch {epoch}, step {global_step}')
                optimizer.zero_grad(set_to_none=True)
                grad_scaler.scale(loss).backward()
                grad_scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), gradient_clipping)
                grad_scaler.step(optimizer)
                grad_scaler.update()

                pbar.update(images.shape[0])
                global_step += 1
                epoch_loss += loss.item() * images.shape[0]
                experiment.log({
                    'train loss': loss.item(),
                    'step': global_step,
                    'epoch': epoch
                })
                pbar.set_postfix(**{'loss (batch)': loss.item()})

        validation, _ = evaluate_binary(model, val_loader, device, amp)
        val_score = validation['macro']['dice']
        if val_score is None:
            raise ValueError('Validation Dice is undefined')
        scheduler.step(val_score)
        history.append(dict(epoch=epoch, train_loss=epoch_loss/n_train,
                            val_dice=val_score, learning_rate=epoch_lr,
                            seconds=time.monotonic()-epoch_started))
        write_csv(run_dir/'history.csv', history)
        logging.info(f'Epoch {epoch}: loss={epoch_loss/n_train:.6f}, validation Dice={val_score:.6f}')
        state_dict = model.state_dict()
        state_dict['mask_values'] = dataset.mask_values
        if val_score > best_score:
            best_score, best_epoch = val_score, epoch
            torch.save(state_dict, run_dir/'best.pth')
        if save_checkpoint:
            torch.save(state_dict, run_dir/'last.pth')

    state = torch.load(run_dir/'best.pth', map_location=device)
    state.pop('mask_values')
    model.load_state_dict(state)
    test_dataset = BasicDataset(test_root/'Original', test_root/'Ground truth', img_scale)
    if test_dataset.mask_values != dataset.mask_values:
        raise ValueError('Test and training mask value mappings differ')
    test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=0)
    summary, rows = evaluate_binary(model, test_loader, device, amp, run_dir)
    config = dict(epochs=epochs, batch_size=batch_size, initial_learning_rate=learning_rate,
                  scale=img_scale, classes=model.n_classes, bilinear=model.bilinear,
                  train_count=n_train, validation_count=n_val, test_count=len(test_dataset),
                  seed=0, amp=amp, device=str(device), torch_version=str(torch.__version__),
                  gpu=torch.cuda.get_device_name(device) if device.type == 'cuda' else None,
                  optimizer='RMSprop', weight_decay=weight_decay, momentum=momentum,
                  loss='BCE or CE + Dice', scheduler='ReduceLROnPlateau, max, patience=5, once per epoch',
                  best_epoch=best_epoch, best_val_dice=best_score,
                  elapsed_seconds=time.monotonic()-started)
    (run_dir/'config.json').write_text(json.dumps(config, indent=2, ensure_ascii=False))
    generate_report(run_dir, config, history, summary, rows)
    experiment.finish()
    logging.info(f'Training and test evaluation complete. Report: {run_dir / "report.html"}')
    return run_dir


def get_args():
    parser = argparse.ArgumentParser(description='Train the UNet on images and target masks')
    parser.add_argument('--epochs', '-e', metavar='E', type=int, default=20, help='Number of epochs')
    parser.add_argument('--batch-size', '-b', dest='batch_size', metavar='B', type=int, default=1, help='Batch size')
    parser.add_argument('--learning-rate', '-l', metavar='LR', type=float, default=1e-5,
                        help='Learning rate', dest='lr')
    parser.add_argument('--load', '-f', type=str, default=False, help='Load model from a .pth file')
    parser.add_argument('--scale', '-s', type=float, default=0.25, help='Downscaling factor of the images')
    parser.add_argument('--validation', '-v', dest='val', type=float, default=10.0,
                        help='Percent of the data that is used as validation (0-100)')
    parser.add_argument('--amp', action='store_true', default=False, help='Use mixed precision')
    parser.add_argument('--bilinear', action='store_true', default=False, help='Use bilinear upsampling')
    parser.add_argument('--classes', '-c', type=int, default=2, help='Number of classes')

    return parser.parse_args()


if __name__ == '__main__':
    args = get_args()
    random.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)

    logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
    device = torch.device('cuda' if torch.cuda.is_available() else 'mps' if torch.backends.mps.is_available() else 'cpu')
    logging.info(f'Using device {device}')

    # Change here to adapt to your data
    # n_channels=3 for RGB images
    # n_classes is the number of probabilities you want to get per pixel
    model = UNet(n_channels=3, n_classes=args.classes, bilinear=args.bilinear)
    model = model.to(memory_format=torch.channels_last)

    logging.info(f'Network:\n'
                 f'\t{model.n_channels} input channels\n'
                 f'\t{model.n_classes} output channels (classes)\n'
                 f'\t{"Bilinear" if model.bilinear else "Transposed conv"} upscaling')

    if args.load:
        state_dict = torch.load(args.load, map_location=device)
        del state_dict['mask_values']
        model.load_state_dict(state_dict)
        logging.info(f'Model loaded from {args.load}')

    model.to(device=device)
    train_model(
        model=model, device=device, epochs=args.epochs, batch_size=args.batch_size,
        learning_rate=args.lr, img_scale=args.scale, val_percent=args.val / 100,
        amp=args.amp
    )
